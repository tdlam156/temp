const s="/assets/icon_19.png";export{s as _};
